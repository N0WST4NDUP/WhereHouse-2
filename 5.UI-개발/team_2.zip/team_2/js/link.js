// ##이재서
var naver = document.querySelector("#naver"),
    daum = document.querySelector("#daum");

naver.addEventListener('click',function() {
    window.open('https://new.land.naver.com/rooms?ms='+marker.getPosition().getLat()+","+marker.getPosition().getLng());
});

// daum.addEventListener('click',function() {
//     window.open('https://realty.daum.net/home/oneroom/items?')
// })