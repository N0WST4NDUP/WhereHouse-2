// ##이재서

var total = document.querySelector("#total"),
    safty = document.querySelector("#safty"),
    conv = document.querySelector("#conv");

async function saftyScore(dist, cctvPcs, density) {
    var value = (100-dist/15)*0.5 + Math.min((cctvPcs/2),100)*0.3 + Math.min((density/0.3),100)*0.2;
    safty.style.width = value + "%";

    totalScore();
}

function convScore(amenity, density) {
    var value = amenity*0.95 - Math.min((density/0.3),100)*0.05;
    conv.style.width = value + "%";
}

function totalScore() {
    var sfScore = parseFloat(safty.style.width),
        cvScore = parseFloat(conv.style.width),
        value = (Math.max(sfScore,cvScore)*1.3 + Math.min(sfScore,cvScore)*0.7)/2;

    console.log(value);
    total.style.width = value + "%";
}

export {saftyScore, convScore}