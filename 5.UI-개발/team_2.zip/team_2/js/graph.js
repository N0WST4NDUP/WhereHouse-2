// ##이재서
import { getDensity } from "./density.js";

var total = document.querySelector("#total"),
    safty = document.querySelector("#safty"),
    conv = document.querySelector("#conv"),
    infoDiv = document.querySelector('#infoDiv'),
    checkBtn = document.querySelector('#check_btn'),
    selected = document.querySelector('#preference');


checkBtn.addEventListener('click',totalScore);
selected.addEventListener('change',totalScore);


document.querySelectorAll('.graphBar').forEach(function(e) {
    e.addEventListener('mouseover', function(e) {
        infoDiv.style.display = 'block';
        infoDiv.style.left = e.pageX+8 + 'px';
        infoDiv.style.top = e.pageY+12 + 'px';
})})
document.querySelectorAll('.graphBar').forEach(function(e) {
    e.addEventListener('mouseout',function() {
        infoDiv.style.display = 'none';
})})
document.querySelectorAll('.graphBar').forEach(function(e) {
    e.addEventListener('mousemove',function(e) {
        infoDiv.style.left = e.pageX+8 + 'px';
        infoDiv.style.top = e.pageY+12 + 'px';
})})
//각 그래프마다 다른 설명 입력
total.addEventListener('mouseover', function() {
    document.querySelector('#infoDivScore').innerHTML = Math.round(parseFloat(total.style.width)) + "점"
    document.querySelector('#infoDivDetail').innerHTML = '토탈점수의 점수산정 기준이 들어갈 자리';
})
safty.addEventListener('mouseover', function() {
    document.querySelector('#infoDivScore').innerHTML = Math.round(parseFloat(safty.style.width)) + "점"
    document.querySelector('#infoDivDetail').innerHTML = '안전점수의 점수산정 기준이 들어갈 자리';
})
conv.addEventListener('mouseover', function() {
    document.querySelector('#infoDivScore').innerHTML = Math.round(parseFloat(conv.style.width)) + "점"
    document.querySelector('#infoDivDetail').innerHTML = '편의점수의 점수산정 기준이 들어갈 자리';
})

function colorChange(e, value) {
    e.style.width = value + "%";

    if (Math.round(parseFloat(e.style.width)) < 30) {
        e.style.backgroundColor = '#1c498d';
    } else if (Math.round(parseFloat(e.style.width)) > 70) {
        e.style.backgroundColor = '#6da7ff';
    } else {
        e.style.backgroundColor = '#4082e6';
    }
}

function totalScore() {
    var sfScore = parseFloat(safty.style.width),
        cvScore = parseFloat(conv.style.width),
        value;
    if (selected.value === 'none') {
        value = (sfScore + cvScore)/2;
    } else if (selected.value === 'safty') {
        value = (sfScore*1.3 + cvScore*0.7)/2;
    } else {
        value = (cvScore*1.3 + sfScore*0.7)/2;
    }
    
    if (checkBtn.checked) {
        getDensity(circle.getPosition(), async function(callback) {
            value = await value * (Math.min((callback/50),1)*0.1 + 1)
            total.style.width = value + "%";
            colorChange(total, value);
        });
    } else {
        total.style.width = value + "%";
        colorChange(total, value);
    }

    // console.log(value);
    // console.log(selected.value)
}

async function saftyScore(dist, cctvPcs, density) {
    var value = (100-dist/15)*0.5 + Math.min((cctvPcs/2),100)*0.3 + Math.min((density/0.3),100)*0.2;
    colorChange(safty, value);

    totalScore();
}

function convScore(amenity, density) {
    console.log(amenity + " " + density);
    var value = amenity - Math.min((density/0.5),100)*0.1;
    colorChange(conv, value);
}

export {saftyScore, convScore}