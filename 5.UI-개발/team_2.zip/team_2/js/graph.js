// ##이재서

var total = document.querySelector("#total"),
    safty = document.querySelector("#safty"),
    conv = document.querySelector("#conv");


kakao.maps.event.addListener(map, 'click', async function() {
    total.style.width = parseInt(Math.random()*100)+"%";
});



async function saftyScore(dist, blindSpot) {
    await console.log(dist + " " + blindSpot);
}

function convScore(value) {
    conv.style.width = value + "%";
}

export {saftyScore, convScore}