// ##이재서
import { getDensity } from "./density.js";

var total = document.querySelector("#total"),
    safty = document.querySelector("#safty"),
    conv = document.querySelector("#conv"),
    checkBtn = document.querySelector('#check_btn'),
    selected = document.querySelector('#preference');

checkBtn.addEventListener('click',totalScore);
selected.addEventListener('change',totalScore);

async function saftyScore(dist, cctvPcs, density) {
    var value = (100-dist/15)*0.5 + Math.min((cctvPcs/2),100)*0.3 + Math.min((density/0.3),100)*0.2;
    safty.style.width = value + "%";

    totalScore();
}

function convScore(amenity, density) {
    var value = amenity*0.95 - Math.min((density/0.3),100)*0.05;
    conv.style.width = value + "%";
}

function totalScore() {
    var sfScore = parseFloat(safty.style.width),
        cvScore = parseFloat(conv.style.width),
        value;
    if (selected.value === 'none') {
        value = (sfScore + cvScore)/2;
    } else if (selected.value === 'safty') {
        value = (sfScore*1.3 + cvScore*0.7)/2;
    } else {
        value = (cvScore*1.3 + sfScore*0.7)/2;
    }
    
    if (checkBtn.checked) {
        getDensity(circle.getPosition(), async function(callback) {
            value = await value * (Math.min((callback/50),1)*0.1 + 1)
            total.style.width = value + "%";
        });
    } else {
        total.style.width = value + "%";
    }

    // console.log(value);
    // console.log(selected.value)
}

export {saftyScore, convScore}