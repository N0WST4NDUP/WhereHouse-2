var param = {
    name:'여성밤길치안안전 - 전체',
    serverUrl:'www.safemap.go.kr/openApiService/wms/getLayerData.do?apikey=JM16ZHUA-JM16-JM16-JM16-JM16ZHUA2K',
    layername:'A2SM_CRMNLHSPOT_F1_TOT',
    styles:'A2SM_OdblrCrmnlHspot_Tot_20_24'
    };

var wmsLayer = new OpenLayers.Layer.WMS (param.name, param.serverUrl,{
        layers: ''+param.layername,
        styles:param.styles,
        format: 'image/png',
        exceptions:'text/xml',
        transparent: true
        }, {isBaseLayer: false});



fetch ('http://www.safemap.go.kr/legend/legendApiXml.do?apikey=JM16ZHUA-JM16-JM16-JM16-JM16ZHUA2K&layer=A2SM_CRMNLHSPOT_F1_TOT&style=A2SM_OdblrCrmnlHspot_Tot_20_24')
        .then(res => res.text())
        .then(xmlText => {
            var parser = new DOMParser();
            var xml = parser.parseFromString(xmlText, 'application/xml');
            console.log(xml);;
        })